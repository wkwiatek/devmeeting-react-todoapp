/* */ 
var root = require('./_root');
var Uint8Array = root.Uint8Array;
module.exports = Uint8Array;
