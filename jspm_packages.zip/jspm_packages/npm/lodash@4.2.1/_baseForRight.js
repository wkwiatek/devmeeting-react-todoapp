/* */ 
var createBaseFor = require('./_createBaseFor');
var baseForRight = createBaseFor(true);
module.exports = baseForRight;
