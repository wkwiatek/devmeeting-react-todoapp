/* */ 
var getNative = require('./_getNative'),
    root = require('./_root');
var Map = getNative(root, 'Map');
module.exports = Map;
