/* */ 
var getNative = require('./_getNative'),
    root = require('./_root');
var WeakMap = getNative(root, 'WeakMap');
module.exports = WeakMap;
