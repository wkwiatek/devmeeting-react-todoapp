/* */ 
var baseProperty = require('./_baseProperty');
var getLength = baseProperty('length');
module.exports = getLength;
