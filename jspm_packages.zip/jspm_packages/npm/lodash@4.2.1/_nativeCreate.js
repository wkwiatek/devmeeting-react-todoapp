/* */ 
var getNative = require('./_getNative');
var nativeCreate = getNative(Object, 'create');
module.exports = nativeCreate;
