/* */ 
var root = require('./_root');
var Symbol = root.Symbol;
module.exports = Symbol;
