/* */ 
var getNative = require('./_getNative'),
    root = require('./_root');
var Set = getNative(root, 'Set');
module.exports = Set;
