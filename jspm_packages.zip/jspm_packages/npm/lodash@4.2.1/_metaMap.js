/* */ 
var WeakMap = require('./_WeakMap');
var metaMap = WeakMap && new WeakMap;
module.exports = metaMap;
