/* */ 
var baseForOwnRight = require('./_baseForOwnRight'),
    createBaseEach = require('./_createBaseEach');
var baseEachRight = createBaseEach(baseForOwnRight, true);
module.exports = baseEachRight;
