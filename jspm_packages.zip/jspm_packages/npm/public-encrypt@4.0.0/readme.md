publicEncrypt
===

[![Build Status](https://travis-ci.org/crypto-browserify/publicEncrypt.svg)](https://travis-ci.org/crypto-browserify/publicEncrypt)

publicEncrypt/privateDecrypt for browserify