/* */ 
module.exports = require('util').deprecate;
